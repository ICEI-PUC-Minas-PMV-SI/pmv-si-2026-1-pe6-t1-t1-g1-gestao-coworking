import 'react-native-gesture-handler';

import { Calendar } from 'react-native-calendars';

import React, { useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  Alert,
  SafeAreaView,
  Linking
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';

const Drawer = createDrawerNavigator();

function SalaScreen({
  route,
  navigation,
  usuarioLogado,
  reservas,
  setReservas
}) {
  
  const salaNome = route.params?.nome || 'Sala de Reunião';


  const [dataSelecionada, setDataSelecionada] =
    useState('');

  const [horarioSelecionado, setHorarioSelecionado] =
    useState('');


  const [comentario, setComentario] = useState('');

  const [avaliacoes, setAvaliacoes] = useState([
    {
      id: 1,
      usuario: 'Maria',
      nota: 5,
      comentario:
        'Excelente ambiente para reuniões.',
    },
    {
      id: 2,
      usuario: 'João',
      nota: 4,
      comentario:
        'Muito confortável e organizado.',
    },
  ]);

  const datas = [
    '10/06',
    '11/06',
    '12/06',
    '13/06',
    '14/06',
  ];

  const horarios = [
    '08:00 - 09:00',
    '09:00 - 10:00',
    '10:00 - 11:00',
    '14:00 - 15:00',
    '15:00 - 16:00',
  ];

  const media =
    (
      avaliacoes.reduce(
        (acc, item) => acc + item.nota,
        0
      ) / avaliacoes.length
    ).toFixed(1);

  function reservar() {

  if (!dataSelecionada) {
    Alert.alert(
      'Aviso',
      'Selecione uma data'
    );
    return;
  }

  if (!horarioSelecionado) {
    Alert.alert(
      'Aviso',
      'Selecione um horário'
    );
    return;
  }

  if (!usuarioLogado) {

    navigation.navigate(
      'Perfil',
      {
        origem: 'reserva'
      }
    );

    return;
  }

  const novaReserva = {
    sala: salaNome,
    data: dataSelecionada,
    horario: horarioSelecionado,
  };

  setReservas([
    ...reservas,
    novaReserva,
  ]);

  Alert.alert(
    'Sucesso',
    'Reserva confirmada!'
  );

  navigation.navigate(
    'Minhas reservas'
  );
}

  function enviarAvaliacao() {
    if (!comentario.trim()) {
      Alert.alert(
        'Aviso',
        'Digite uma avaliação'
      );
      return;
    }

    const nova = {
      id: Date.now(),
      usuario: 'Você',
      nota: 5,
      comentario,
    };

    setAvaliacoes([
      nova,
      ...avaliacoes,
    ]);

    setComentario('');
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>
        {salaNome}
      </Text>

      <Text style={styles.subtitulo}>
        Sala moderna para reuniões e
        trabalho colaborativo.
      </Text>

      {/* IMAGENS */}

      <Text style={styles.sectionTitle}>
        Fotos
      </Text>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
      >
        <Image
          source={{
            uri: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200',
          }}
          style={styles.image}
        />

        <Image
          source={{
            uri: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=1200',
          }}
          style={styles.image}
        />

        <Image
          source={{
            uri: 'https://images.unsplash.com/photo-1497366412874-3415097a27e7?w=1200',
          }}
          style={styles.image}
        />
      </ScrollView>

      {/* AVALIAÇÃO GERAL */}

      <View style={styles.ratingCard}>
        <Text style={styles.rating}>
          ⭐ {media}
        </Text>

        <Text>
          {avaliacoes.length} avaliações
        </Text>
      </View>

      {/* COMODIDADES */}

      <Text style={styles.sectionTitle}>
        Comodidades
      </Text>

      <View style={styles.card}>
        <Text>📶 Wi-Fi de alta velocidade</Text>
        <Text>❄️ Ar-condicionado</Text>
        <Text>📺 Projetor</Text>
        <Text>🅿️ Estacionamento</Text>
        <Text>☕ Café disponível</Text>
      </View>

      {/* CALENDÁRIO SIMULADO */}

      <Text style={styles.sectionTitle}>
        Disponibilidade
      </Text>

     <Calendar
  onDayPress={(day) =>
    setDataSelecionada(day.dateString)
  }
  markedDates={{
    [dataSelecionada]: {
      selected: true,
      selectedColor: '#091B3C'
    }
  }}
/>

      {/* HORÁRIOS */}

      <Text style={styles.sectionTitle}>
        Horários
      </Text>

      {horarios.map((hora) => (
        <TouchableOpacity
          key={hora}
          style={[
            styles.timeButton,
            horarioSelecionado ===
              hora &&
              styles.selectedButton,
          ]}
          onPress={() =>
            setHorarioSelecionado(hora)
          }
        >
          <Text>{hora}</Text>
        </TouchableOpacity>
      ))}

      {/* RESERVAR */}

      <TouchableOpacity
        style={styles.reserveButton}
        onPress={reservar}
      >
        <Text style={styles.reserveText}>
          Reservar
        </Text>
      </TouchableOpacity>

      {/* ESCREVER AVALIAÇÃO */}

      <Text style={styles.sectionTitle}>
        Escrever Avaliação
      </Text>

      <TextInput
        style={styles.input}
        multiline
        placeholder="Digite sua avaliação..."
        value={comentario}
        onChangeText={setComentario}
      />

      <TouchableOpacity
        style={styles.reserveButton}
        onPress={enviarAvaliacao}
      >
        <Text style={styles.sendText}>
          Enviar Avaliação
        </Text>
      </TouchableOpacity>

      {/* LISTA */}

      <Text style={styles.sectionTitle}>
        Comentários
      </Text>

      {avaliacoes.map((item) => (
        <View
          key={item.id}
          style={styles.review}
        >
          <Text>
            ⭐ {item.nota}
          </Text>

          <Text style={styles.user}>
            {item.usuario}
          </Text>

          <Text>
            {item.comentario}
          </Text>
        </View>
      ))}
    </ScrollView>
  );
}

function BuscarEspacosScreen({ navigation }) {
   // Estados
  const [categoriaSelecionada,
    setCategoriaSelecionada] =
    useState('Todos');
 const espacos = [
  {
    id: 1,
    nome: 'Sala Executiva',
    tipo: 'Sala de Reunião',
    capacidade: 6,
    imagem:
      'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200'
  },

  {
    id: 2,
    nome: 'Sala Premium',
    tipo: 'Sala de Reunião',
    capacidade: 10,
    imagem:
      'https://images.unsplash.com/photo-1497366412874-3415097a27e7?w=1200'
  },

  {
    id: 3,
    nome: 'Privativo 01',
    tipo: 'Espaço Privativo',
    capacidade: 2,
    imagem:
      'https://images.unsplash.com/photo-1497215842964-222b430dc094?w=1200'
  },

  {
    id: 4,
    nome: 'Privativo 02',
    tipo: 'Espaço Privativo',
    capacidade: 2,
    imagem:
      'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=1200'
  },

  {
    id: 5,
    nome: 'Mesa Compartilhada A',
    tipo: 'Mesa Compartilhada',
    capacidade: 1,
    imagem:
      'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1200'
  },

  {
    id: 6,
    nome: 'Estação Fixa 01',
    tipo: 'Estação Fixa',
    capacidade: 1,
    imagem:
      'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200'
  }
];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>
        Buscar Espaços
      </Text>

      <Text style={styles.subtitulo}>
        Escolha o tipo de espaço desejado
      </Text>

    {/* FILTROS */}

<ScrollView
  horizontal
  showsHorizontalScrollIndicator={false}
  style={{ marginBottom: 20 }}
>
  {[
    'Todos',
    'Espaço Privativo',
    'Mesa Compartilhada',
    'Estação Fixa',
    'Sala de Reunião'
  ].map((categoria) => (
    <TouchableOpacity
      key={categoria}
      style={[
        styles.filtroCategoria,
        categoriaSelecionada === categoria &&
          styles.filtroCategoriaAtivo
      ]}
      onPress={() =>
        setCategoriaSelecionada(categoria)
      }
    >
      <Text>{categoria}</Text>
    </TouchableOpacity>
  ))}
</ScrollView>

{/* LISTA DE ESPAÇOS */}

{espacos
  .filter(
    (item) =>
      categoriaSelecionada === 'Todos' ||
      item.tipo === categoriaSelecionada
  )
  .map((espaco) => (
    <View
      key={espaco.id}
      style={styles.espacoCard}
    >
      <Image
        source={{
          uri: espaco.imagem,
        }}
        style={styles.espacoImagem}
      />

      <Text style={styles.espacoTitulo}>
        {espaco.nome}
      </Text>

      <Text style={styles.espacoDescricao}>
       {espaco.tipo}
      </Text>

      <Text style={{ marginTop: 5 }}>
        Capacidade: {espaco.capacidade} pessoas
      </Text>

      <TouchableOpacity
        style={styles.reserveButton}
        onPress={() =>
          navigation.navigate(
            'Detalhes da Sala',
            {
              nome: espaco.nome,
            }
          )
        }
      >
        <Text style={styles.reserveText}>
          Ver Disponibilidade
        </Text>
      </TouchableOpacity>
    </View>
  ))}
    </ScrollView>
  );
}

function PlanosScreen() {

  const planos = [
    {
      id: 1,
      nome: 'Day Pass',
      periodo: 'Diário',
      preco: 'R$ 60/dia',
      beneficios: [
        'Acesso ao coworking durante o dia',
        'Wi-Fi de alta velocidade',
        'Café e água inclusos',
        'Uso das áreas comuns'
      ]
    },

    {
      id: 2,
      nome: 'Flex',
      periodo: 'Semanal',
      preco: 'R$ 480/semana',
      beneficios: [
        'Acesso flexível',
        'Wi-Fi de alta velocidade',
        'Uso das salas mediante reserva',
        'Áreas compartilhadas'
      ]
    },

    {
      id: 3,
      nome: 'Dedicated',
      periodo: 'Mensal',
      preco: 'R$ 1.180/mês',
      beneficios: [
        'Mesa exclusiva',
        'Armário individual',
        'Acesso durante horário comercial',
        'Internet dedicada'
      ]
    },

    {
      id: 4,
      nome: 'Office',
      periodo: 'Anual',
      preco: 'R$ 3.200/ano',
      beneficios: [
        'Sala privativa',
        'Acesso 24h',
        'Endereço comercial',
        'Prioridade em reservas'
      ]
    }
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>
        Nossos Planos
      </Text>

      <Text style={styles.subtitulo}>
        Escolha o plano ideal para sua rotina.
      </Text>

      {planos.map((plano) => (

        <View
          key={plano.id}
          style={styles.planoCard}
        >

          <Text style={styles.planoNome}>
            {plano.nome}
          </Text>

          <Text style={styles.planoPeriodo}>
            {plano.periodo}
          </Text>

          <Text style={styles.planoPreco}>
            {plano.preco}
          </Text>

          {plano.beneficios.map(
            (beneficio, index) => (
              <Text key={index}>
                ✓ {beneficio}
              </Text>
            )
          )}

          <TouchableOpacity
            style={styles.reserveButton}
          >
            <Text style={styles.reserveText}>
              Assinar Plano
            </Text>
          </TouchableOpacity>

        </View>

      ))}

    </ScrollView>
  );
}
function LoginScreen({
  navigation,
  route,
  setUsuarioLogado
}) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  function fazerLogin() {

  if (!email || !senha) {

    Alert.alert(
      'Atenção',
      'Preencha todos os campos'
    );

    return;
  }

  setUsuarioLogado(true);

  Alert.alert(
    'Sucesso',
    'Login realizado!'
  );

  if (
    route?.params?.origem ===
    'reserva'
  ) {

    navigation.navigate('Início');

  } else {

    navigation.navigate(
      'Início'
    );

  }
}

  return (
    <ScrollView style={styles.container}>

      <Text style={styles.titulo}>
        Entrar
      </Text>

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      <TouchableOpacity
        style={styles.reserveButton}
        onPress={fazerLogin}
      >
        <Text style={styles.reserveText}>
          Entrar
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() =>
          navigation.navigate('Cadastro')
        }
      >
        <Text
          style={{
            textAlign: 'center',
            marginTop: 20,
            color: '#17314F'
          }}
        >
          Não possui conta? Cadastre-se
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}
function CadastroScreen() {

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  function cadastrar() {

    if (!nome || !email || !senha) {
      Alert.alert(
        'Atenção',
        'Preencha todos os campos'
      );
      return;
    }

    Alert.alert(
      'Sucesso',
      'Cadastro realizado!'
    );
  }

  return (
    <ScrollView style={styles.container}>

      <Text style={styles.titulo}>
        Criar Conta
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Nome"
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      <TouchableOpacity
        style={styles.reserveButton}
        onPress={cadastrar}
      >
        <Text style={styles.reserveText}>
          Criar Conta
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

function MinhasReservasScreen({
  reservas
}) {

  return (

    <ScrollView
      style={styles.container}
    >

      <Text style={styles.titulo}>
        Minhas Reservas
      </Text>

      {reservas.length === 0 ? (

        <Text
          style={styles.subtitulo}
        >
          Nenhuma reserva encontrada.
        </Text>

      ) : (

        reservas.map(
          (
            reserva,
            index
          ) => (

            <View
              key={index}
              style={
                styles.reservaCard
              }
            >

              <Text
                style={
                  styles.reservaTitulo
                }
              >
                {reserva.sala}
              </Text>

              <Text>
                📅 {reserva.data}
              </Text>

              <Text>
                🕒 {reserva.horario}
              </Text>

            </View>

          )
        )

      )}

    </ScrollView>

  );
}

export default function App() {

  const [reservas, setReservas] =
    useState([]);

  const [usuarioLogado, setUsuarioLogado] =
    useState(false);

  return (
    <NavigationContainer>

      <Drawer.Navigator>

        <Drawer.Screen
          name="Início"
        >
          {(props) => (
            <SalaScreen
              {...props}
              usuarioLogado={usuarioLogado}
              reservas={reservas}
              setReservas={setReservas}
            />
          )}
        </Drawer.Screen>

        <Drawer.Screen
          name="Buscar Espaços"
          component={BuscarEspacosScreen}
        />

        <Drawer.Screen
          name="Detalhes da Sala"
          options={{
            drawerItemStyle: {
              display: 'none'
            }
          }}
        >
          {(props) => (
            <SalaScreen
              {...props}
              usuarioLogado={usuarioLogado}
              reservas={reservas}
              setReservas={setReservas}
            />
          )}
        </Drawer.Screen>

        <Drawer.Screen
          name="Minhas reservas"
        >
          {(props) => (
            <MinhasReservasScreen
              {...props}
              reservas={reservas}
            />
          )}
        </Drawer.Screen>

        <Drawer.Screen
          name="Planos"
          component={PlanosScreen}
        />

        <Drawer.Screen
          name="Perfil"
        >
          {(props) => (
            <LoginScreen
              {...props}
              setUsuarioLogado={
                setUsuarioLogado
              }
            />
          )}
        </Drawer.Screen>

        <Drawer.Screen
          name="Cadastro"
          options={{
            drawerItemStyle: {
              display: 'none'
            }
          }}
        >
          {(props) => (
            <CadastroScreen
              {...props}
            />
          )}
        </Drawer.Screen>

      </Drawer.Navigator>

    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F6F8',
    padding: 15,
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 10,
  },

  subtitulo: {
    color: '#666',
    marginBottom: 20,
  },

  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },

  image: {
    width: 300,
    height: 200,
    borderRadius: 12,
    marginRight: 10,
  },

  ratingCard: {
    backgroundColor: '#FFF',
    padding: 15,
    borderRadius: 12,
    marginTop: 15,
  },

  rating: {
    fontSize: 30,
    fontWeight: 'bold',
  },

  card: {
    backgroundColor: '#FFF',
    padding: 15,
    borderRadius: 12,
  },

  dateButton: {
    backgroundColor: '#FFF',
    padding: 15,
    marginRight: 10,
    borderRadius: 10,
  },

  timeButton: {
    backgroundColor: '#FFF',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },

  selectedButton: {
    borderWidth: 2,
    borderColor: '#17314F',
  },

  reserveButton: {
    backgroundColor: '#17314F',
    padding: 18,
    borderRadius: 30,
    alignItems: 'center',
    marginTop: 15,
  },

  reserveText: {
    color: '#FFF',
    fontWeight: 'bold',
    fontSize: 16,
  },

  input: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 15,
    minHeight: 100,
    textAlignVertical: 'top',
  },

  sendButton: {
    backgroundColor: '#17314F',
    padding: 15,
    borderRadius: 10,
    marginTop: 10,
    alignItems: 'center',
  },

  sendText: {
    color: '#FFF',
    fontWeight: 'bold',
  },

  review: {
    backgroundColor: '#FFF',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
  },

  user: {
    fontWeight: 'bold',
    marginVertical: 5,
  },
  espacoCard: {
  backgroundColor: '#FFF',
  padding: 20,
  borderRadius: 12,
  marginBottom: 15,
},

espacoTitulo: {
  fontSize: 20,
  fontWeight: 'bold',
  color: '#17314F',
  marginBottom: 8,
},

espacoDescricao: {
  color: '#666',
  marginBottom: 15,
},
filtroCategoria: {
  backgroundColor: '#FFF',
  paddingHorizontal: 15,
  paddingVertical: 10,
  borderRadius: 20,
  marginRight: 10,
},

filtroCategoriaAtivo: {
  borderWidth: 2,
  borderColor: '#17314F',
},

espacoImagem: {
  width: '100%',
  height: 180,
  borderRadius: 12,
  marginBottom: 10,
},
planoCard: {
  backgroundColor: '#FFF',
  borderRadius: 15,
  padding: 20,
  marginBottom: 20,
},

planoNome: {
  fontSize: 24,
  fontWeight: 'bold',
  color: '#17314F',
},

planoPeriodo: {
  fontSize: 16,
  color: '#666',
  marginTop: 5,
},

planoPreco: {
  fontSize: 28,
  fontWeight: 'bold',
  marginVertical: 15,
  color: '#17314F',
},


reservaCard: {
  backgroundColor: '#FFF',
  padding: 20,
  borderRadius: 12,
  marginBottom: 15,
},

reservaTitulo: {
  fontSize: 18,
  fontWeight: 'bold',
  color: '#17314F',
  marginBottom: 10,
},
});

