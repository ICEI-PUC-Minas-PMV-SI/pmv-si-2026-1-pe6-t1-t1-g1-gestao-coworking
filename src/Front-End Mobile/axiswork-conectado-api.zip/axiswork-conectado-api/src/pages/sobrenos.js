import React from 'react';

import HeaderBack from '../components/HeaderBack';
import Container from '../components/Container';

import { Titulo1 } from '../components/Texto';

const SobreNos = () => {
  return (
    <Container>
      <HeaderBack></HeaderBack>
      <Titulo1>Sobre Nós</Titulo1>
    </Container>
  );
};

export default SobreNos;
