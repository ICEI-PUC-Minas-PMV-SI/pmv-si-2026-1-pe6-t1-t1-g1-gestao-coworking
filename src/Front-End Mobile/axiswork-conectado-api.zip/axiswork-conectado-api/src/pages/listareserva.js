import React from 'react';

import HeaderBack from '../components/HeaderBack';
import Container from '../components/Container';

import { Titulo1 } from '../components/Texto';

const ListaReserva = () => {
  return (
    <Container>
      <HeaderBack></HeaderBack>
      <Titulo1>Lista das Reservas</Titulo1>
    </Container>
  );
};

export default ListaReserva;
