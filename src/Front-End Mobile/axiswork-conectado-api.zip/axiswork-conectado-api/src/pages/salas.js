import React from 'react';

import Header from '../components/Header';
import Container from '../components/Container';

import { Titulo1 } from '../components/Texto';

const Sala = () => {
  return (
    <Container>
      <Header></Header>
      <Titulo1>Salas</Titulo1>
    </Container>
  );
};

export default Sala;
