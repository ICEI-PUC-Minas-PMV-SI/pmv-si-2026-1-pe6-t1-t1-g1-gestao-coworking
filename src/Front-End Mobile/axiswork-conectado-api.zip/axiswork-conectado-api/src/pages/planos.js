import React from 'react';

import HeaderBack from '../components/HeaderBack';
import Container from '../components/Container';

import { Titulo1 } from '../components/Texto';

const Plano = () => {
  return (
    <Container>
      <HeaderBack></HeaderBack>
      <Titulo1>Planos</Titulo1>
    </Container>
  );
};

export default Plano;
