import React, { useState, useEffect } from 'react';
import { StyleSheet, Image, View, ActivityIndicator } from 'react-native';
import { Card, IconButton } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';

import Header from '../components/Header';
import Container from '../components/Container';
import {
  Titulo1,
  Titulo2,
  Titulo3,
  Titulo4,
  Titulo5,
} from '../components/Texto';
import { Botao1 } from '../components/Botao';

const MOCK_USUARIO_LOGADO = {
  id: '1',
  nome: 'Guilherme',
  email: 'guilherme@email.com',
};

const BASE_URL = 'https://axis-work.loca.lt/';

const Home = ({ route }) => {
  // const { jumpTo, usuarioLogado } = route.params || {};
  const { jumpTo } = route.params || {}; // Apagar e descomentar o de cima quando parar de usar o mock

  //const [usuario, setUsuario] = useState(usuarioLogado);
  const [usuario, setUsuario] = useState(MOCK_USUARIO_LOGADO); // Apagar e descomentar o de cima quando parar de usar o mock

  const navigation = useNavigation();

  const [salas, setSalas] = useState([]);
  const [proximaReserva, setProximaReserva] = useState(null);
  const [planos, setPlanos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!usuario?.id) {
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      try {
        setLoading(true);

        const resSalas = await fetch(`${BASE_URL}/api/salas?ativas=true`);
        const dadosSalas = await resSalas.json();

        const tiposDeSala = [
          '1 Mesa de Trabalho',
          '2 Sala Individual',
          '3 Sala de Atendimento',
          '4 Sala de Reunião',
        ];
        const salasFiltradas = tiposDeSala
          .map((tipo) => {
            return dadosSalas.find(
              (sala) => String(sala.tipo) === String(tipo)
            );
          })
          .filter(Boolean);

        setSalas(salasFiltradas);

        const resReservas = await fetch(
          `${BASE_URL}/api/reservas?id_cliente=${usuario.id}`
        );
        const dadosReservas = await resReservas.json();

        const agora = new Date();
        const reservasValidas = dadosReservas
          .filter(
            (res) =>
              res.status === 'Confirmada' && new Date(res.entrada) > agora
          )
          .sort((a, b) => new Date(a.entrada) - new Date(b.entrada));

        if (reservasValidas.length > 0) {
          const prox = reservasValidas[0];
          const salaInfo = dadosSalas.find((s) => s.id_sala === prox.id_sala);
          setProximaReserva({
            ...prox,
            nome_sala: salaInfo ? salaInfo.nome : 'Sala Desconhecida',
          });
        } else {
          setProximaReserva(null);
        }

        const resPlanos = await fetch(`${BASE_URL}/planos/`);
        const dadosPlanos = await resPlanos.json();
        setPlanos(dadosPlanos);
      } catch (error) {
        console.error('Erro ao buscar dados da API:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [usuario]);

  const formatarData = (dataIso) => {
    if (!dataIso) return '';
    const d = new Date(dataIso);
    return d.toLocaleDateString('pt-BR');
  };

  const formatarHora = (dataIso) => {
    if (!dataIso) return '';
    const d = new Date(dataIso);
    return d.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#fff',
        }}>
        <ActivityIndicator size="large" color="#0F2A44" />
      </View>
    );
  }

  return (
    <>
      <Header />
      <Container>
        {proximaReserva ? (
          <Card style={styles.proxRes}>
            <Card.Content style={styles.cardContent}>
              <Card.Content>
                <Titulo1>Sua Próxima Reserva</Titulo1>
                <Titulo2>
                  <IconButton
                    icon="map-marker"
                    color={'#0F2A44'}
                    size={15}
                    style={styles.icones}
                  />
                  {proximaReserva.nome_sala}
                </Titulo2>
                <Titulo3>
                  <IconButton
                    icon="calendar"
                    color={'#5B748C'}
                    size={15}
                    style={styles.icones}
                  />
                  {formatarData(proximaReserva.entrada)}
                </Titulo3>
                <Titulo3>
                  <IconButton
                    icon="clock"
                    color={'#5B748C'}
                    size={15}
                    style={styles.icones}
                  />
                  Entra: {formatarHora(proximaReserva.entrada)} | Sai:{' '}
                  {formatarHora(proximaReserva.saida)}
                </Titulo3>
              </Card.Content>
              <Card.Content>
                <Image
                  source={{ uri: 'https://picsum.photos/600?random=reserva' }}
                  style={styles.reservationImage}
                />
              </Card.Content>
            </Card.Content>
            <Card.Content style={styles.cardContentBot}>
              <Botao1 onPress={() => navigation.navigate('ListaReserva')}>
                Ver Reservas
              </Botao1>
            </Card.Content>
          </Card>
        ) : (
          <Card style={styles.proxRes}>
            <Card.Content
              style={[styles.cardContentBot, { paddingVertical: 20 }]}>
              <Titulo3 style={{ color: '#5B748C', textAlign: 'center' }}>
                Você não possui nenhuma reserva ativa.
              </Titulo3>
            </Card.Content>
          </Card>
        )}

        <Titulo4>Conheça Nossas Salas</Titulo4>
        <View style={styles.grid}>
          {salas.map((sala, index) => (
            <Card
              key={sala.id_sala || index}
              style={styles.salasCard}
              onPress={() => jumpTo('salas')}>
              <Image
                source={{
                  uri: `https://picsum.photos/600?random=sala_${index}`,
                }}
                style={styles.salasImg}
              />
              <Titulo2>{sala.tipo}</Titulo2>
              <Titulo3>{sala.recursos || 'Sem recursos descritos'}</Titulo3>
              <Titulo3>{sala.capacidade} pessoas</Titulo3>
            </Card>
          ))}
        </View>

        <Titulo4>Conheça Nossas Planos</Titulo4>
        <View>
          {planos.map((plano, index) => (
            <Card key={index} style={styles.planosCard}>
              <Titulo2
                style={{ textAlign: 'center', justifyContent: 'center' }}>
                {plano.nome}
              </Titulo2>
              <View style={styles.flexRow}>
                <Titulo4>R${parseFloat(plano.preco).toFixed(2)}</Titulo4>
                <Titulo3>/mês</Titulo3>
              </View>
              <Botao1
                onPress={() =>
                  navigation.navigate('Assinaturas', { plano: plano.nome })
                }>
                Assine Já
              </Botao1>
            </Card>
          ))}

          <View style={styles.planoBot}>
            <Botao1 onPress={() => navigation.navigate('Planos')}>
              Conheça os Planos
            </Botao1>
          </View>
        </View>

        <Titulo4>Contato e Suporte</Titulo4>
        <View>
          <Card style={styles.sobreCard}>
            <Titulo5>
              <IconButton
                icon="email"
                color={'#0F2A44'}
                size={15}
                style={styles.icones}
              />
              contato@axiswork.com
            </Titulo5>
            <Titulo5>
              <IconButton
                icon="whatsapp"
                color={'#0F2A44'}
                size={15}
                style={styles.icones}
              />
              (31) 9999-9999
            </Titulo5>
            <Titulo5>
              <IconButton
                icon="map-marker"
                color={'#0F2A44'}
                size={15}
                style={styles.icones}
              />
              Av. do Contorno, 1000 - MG
            </Titulo5>
            <View style={styles.planoBot}>
              <Botao1 onPress={() => navigation.navigate('SobreNos')}>
                Sobre Nós
              </Botao1>
            </View>
          </Card>
        </View>
      </Container>
    </>
  );
};

const styles = StyleSheet.create({
  proxRes: {
    backgroundColor: '#fff',
    borderRadius: 20,
    margin: 10,
  },
  cardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  cardContentBot: {
    alignItems: 'center',
  },
  reservationImage: {
    width: 80,
    height: 80,
    borderRadius: 15,
  },
  icones: {
    margin: 0,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    margin: 10,
  },
  salasCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    width: '48%',
    padding: 10,
    marginBottom: 10,
  },
  salasImg: {
    width: '100%',
    height: 90,
    borderRadius: 15,
    marginBottom: 10,
  },
  planosCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    borderWidth: 2,
    borderColor: '#0F2A44',
    width: '60%',
    alignItems: 'center',
    alignSelf: 'center',
    padding: 10,
    paddingVertical: 30,
    marginTop: 15,
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 20,
  },
  planoBot: {
    width: '70%',
    alignSelf: 'center',
    marginTop: 20,
    marginBottom: 10,
  },
  sobreCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    width: '95%',
    alignSelf: 'center',
    padding: 20,
    marginTop: 15,
    marginBottom: 30,
  },
});

export default Home;
