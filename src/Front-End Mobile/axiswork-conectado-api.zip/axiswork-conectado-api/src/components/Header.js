import React from 'react';

import { StyleSheet } from 'react-native';

import { Appbar } from 'react-native-paper';

const Header = () => {
  return (
    <Appbar.Header style={styles.header}>
      <Appbar.Content
        title="Axis Work"
        titleStyle={styles.text}></Appbar.Content>
    </Appbar.Header>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#fff',
    elevation: 2,
    marginTop: 25,
  },

  text: {
    textAlign: 'center',
    fontWeight: '800',
    fontSize: 25,
    color: '#0F2A44',
  },
});

export default Header;
