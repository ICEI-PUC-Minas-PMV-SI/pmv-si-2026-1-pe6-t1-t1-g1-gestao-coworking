import React from 'react';
import { StyleSheet } from 'react-native';
import { Text } from 'react-native-paper';

const Titulo1 = ({ children }) => {
  return <Text style={styles.titulo1}>{children}</Text>;
};

const Titulo2 = ({ children, style }) => {
  return <Text style={[styles.titulo2, style]}>{children}</Text>;
};

const Titulo3 = ({ children }) => {
  return <Text style={styles.titulo3}>{children}</Text>;
};

const Titulo4 = ({ children }) => {
  return <Text style={styles.titulo4}>{children}</Text>;
};

const Titulo5 = ({ children }) => {
  return <Text style={styles.titulo5}>{children}</Text>;
};

const styles = StyleSheet.create({
  titulo1: {
    fontWeight: '600',
    color: '#5B748C',
    fontSize: 18,
    marginBottom: 5,
  },
  titulo2: {
    fontWeight: '600',
    color: '#0F2A44',
    fontSize: 16,
    marginBottom: 5,
  },
  titulo3: {
    fontWeight: '500',
    color: '#5B748C',
    fontSize: 16,
  },
  titulo4: {
    textAlign: 'center',
    fontWeight: '800',
    color: '#0F2A44',
    fontSize: 25,
    marginTop: 10,
  },
  titulo5: {
    fontWeight: '400',
    color: '#0F2A44',
    fontSize: 16,
    marginBottom: 5,
  },
});

export { Titulo1, Titulo2, Titulo3, Titulo4, Titulo5 };
