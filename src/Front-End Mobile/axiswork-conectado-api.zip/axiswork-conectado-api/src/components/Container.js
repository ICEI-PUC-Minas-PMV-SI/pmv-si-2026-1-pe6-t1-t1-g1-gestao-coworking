import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';

const Container = ({ children }) => {
  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      style={styles.container}>
      {children}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#CAD6E233',
    paddingBottom: 20,
  },
});

export default Container;
