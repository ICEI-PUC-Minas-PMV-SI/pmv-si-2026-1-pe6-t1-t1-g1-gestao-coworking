import React from 'react';
import { StyleSheet } from 'react-native';
import { Appbar } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';

const HeaderBack = () => {
  const navigation = useNavigation();
  return (
    <Appbar.Header style={styles.header}>
    <Appbar.BackAction 
          color="#0F2A44" 
          onPress={() => navigation.goBack()} 
        />
      <Appbar.Content title="Axis Work" titleStyle={styles.text} />
      <Appbar.Action icon={() => null} color="transparent" disabled />
    </Appbar.Header>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#fff',
    elevation: 2,
    marginTop: 25,
  },
  text: {
    textAlign: 'center',
    fontWeight: '800',
    fontSize: 25,
    color: '#0F2A44',
  },
});

export default HeaderBack;
