import React from 'react';
import { StyleSheet } from 'react-native';
import { Button } from 'react-native-paper';

const Botao1 = ({ children, onPress, icon }) => {
  return (
    <Button
      mode="contained"
      theme={{ colors: { primary: '#0F2A44' } }}
      style={styles.botao}
      icon={icon}
      onPress={onPress}>
      {children}
    </Button>
  );
};

const Botao2 = ({ children, onPress, icon }) => {
  return (
    <Button
      mode="contained"
      theme={{ colors: { primary: '#5B748C' } }}
      style={styles.botao}
      icon={icon}
      onPress={onPress}>
      {children}
    </Button>
  );
};

const styles = StyleSheet.create({
  botao: {
    borderRadius: 100,
    paddingHorizontal:5,
  },
});

export { Botao1, Botao2 };
