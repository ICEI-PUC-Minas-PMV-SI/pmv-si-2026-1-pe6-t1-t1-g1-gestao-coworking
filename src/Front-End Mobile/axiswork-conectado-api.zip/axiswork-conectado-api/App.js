//lt --port 8001 --subdomain axis-work

import React from 'react';
import { BottomNavigation, Provider, DefaultTheme } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native'; 
import { createNativeStackNavigator } from '@react-navigation/native-stack'; 

import Home from './src/pages/home';
import Reserva from './src/pages/reservas';
import Sala from './src/pages/salas';
import Perfil from './src/pages/perfil';
import Plano from './src/pages/planos';
import Assinatura from './src/pages/assinatura';
import ListaReserva from './src/pages/listareserva';
import SobreNos from './src/pages/sobrenos';

const theme = {
  ...DefaultTheme,
  dark: false,
};

const Stack = createNativeStackNavigator();

const HomeStack = ({ jumpTo }) => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="HomePrincipal"
        component={Home}
        initialParams={{ jumpTo: jumpTo }}
      />
      <Stack.Screen name="Planos" component={Plano} />
      <Stack.Screen name="Assinaturas" component={Assinatura} />
      <Stack.Screen name="ListaReserva" component={ListaReserva} />
      <Stack.Screen name="SobreNos" component={SobreNos} />
    </Stack.Navigator>
  );
};

const App = () => {
  const [index, setIndex] = React.useState(0);
  const [routes] = React.useState([
    { key: 'home', title: 'Home', icon: 'home' },
    { key: 'reservas', title: 'Reservas', icon: 'calendar' },
    { key: 'salas', title: 'Salas', icon: 'office-building' },
    { key: 'perfil', title: 'Perfil', icon: 'account' },
  ]);

  const renderScene = BottomNavigation.SceneMap({
    home: HomeStack,
    reservas: Reserva,
    salas: Sala,
    perfil: Perfil,
  });

  return (
    <Provider theme={theme}>
      <NavigationContainer>
        <HomeStack/>
      </NavigationContainer>
    </Provider>
  );
};

export default App;
